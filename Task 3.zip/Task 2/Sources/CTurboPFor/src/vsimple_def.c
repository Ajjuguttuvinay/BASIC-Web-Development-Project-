

/*#undef __AVX2__

#define GUARDED
#include "vsimple.c"
*/
