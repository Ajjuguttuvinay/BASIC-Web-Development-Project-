# Product Landing Page Website

This repository contains a personal project developed as part of FreeCodeCamp's Responsive Web Design Certification. The project is a product landing page website, designed to showcase a particular product and its features.
